wget http://cs231n.stanford.edu/tiny-100-A-pretrained.zip
unzip tiny-100-A-pretrained.zip
rm tiny-100-A-pretrained.zip
